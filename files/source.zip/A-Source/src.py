import os
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

# Create the main folder where the website will be saved
BASE_FOLDER = "localsaved"
os.makedirs(BASE_FOLDER, exist_ok=True)

# Function to download and save a file
def download_file(session, url, folder):
    try:
        response = session.get(url, stream=True)
        if response.status_code == 200:
            # Extract the filename from URL
            filename = os.path.join(folder, os.path.basename(urlparse(url).path))
            
            # If the filename is empty (e.g., a directory), assign a default name
            if not os.path.basename(filename):
                filename = os.path.join(folder, "index.html")
            
            # Write the file
            with open(filename, "wb") as file:
                for chunk in response.iter_content(1024):
                    file.write(chunk)
            print(f"Downloaded: {filename}")
    except Exception as e:
        print(f"Failed to download {url}: {e}")

# Function to clone a website and save it into localsaved
def clone_website(url):
    session = requests.Session()
    response = session.get(url)
    
    if response.status_code != 200:
        print("Failed to retrieve the website")
        return
    
    soup = BeautifulSoup(response.text, "html.parser")

    # Save the main HTML page in localsaved folder
    html_path = os.path.join(BASE_FOLDER, "index.html")
    with open(html_path, "w", encoding="utf-8") as file:
        file.write(soup.prettify())
    print(f"Saved main HTML: {html_path}")

    # Download assets (CSS, JS, Images)
    for tag in soup.find_all(["link", "script", "img"]):
        src = tag.get("href") or tag.get("src")
        if src:
            asset_url = urljoin(url, src)
            asset_folder = os.path.join(BASE_FOLDER, os.path.dirname(urlparse(asset_url).path).strip("/"))
            os.makedirs(asset_folder, exist_ok=True)
            download_file(session, asset_url, asset_folder)

# Get user input for the website URL
website_url = input("Enter the website URL to clone: ")
clone_website(website_url)
